package com.sap.cloud.sdk.tutorial;

import org.junit.Test;

import static org.junit.Assert.*;

public class UnitTest {
    @Test
    public void test() {
        assertTrue(true);
    }
}
